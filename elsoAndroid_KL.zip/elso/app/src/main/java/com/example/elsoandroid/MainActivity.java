package com.example.elsoandroid;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText varEmail;
    private EditText varPassword;
    private Button varLogin;
    private Button varRegister;
    private TextView varAnswer;
    private Button varInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        varEmail = findViewById(R.id.txtEmail);
        varPassword = findViewById(R.id.txtPassword);
        varLogin = findViewById(R.id.btnLogin);
        varRegister = findViewById(R.id.btnRegister);
        varAnswer = findViewById(R.id.rpValasz);
        varInfo = findViewById(R.id.btnInfo);

        varLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = varEmail.getText().toString();
                String password = varPassword.getText().toString();

                String goodAnswer = "Sikeres bejelentkezés!";
                String badPassword = "A jelszónak legalább 8 karakternek kell lennie!";
                String badEmail = "Az email nem tartalmaz helyes formátumot (@ ; .com)";
                int minLength = 8;
                int maxLength = 16;

                if (email.contains("@") && email.contains(".com")) {
                    if (password.length() >= minLength) {
                        varAnswer.setText(goodAnswer);
                    } else if (password.length() < minLength) {
                        varAnswer.setText(badPassword);
                    } else if(!email.contains("@") || !email.contains(".com")) {
                        varAnswer.setText(badEmail);
                    }
                }
            }
        });

        varInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
    }
}